# Satithan Legal Heir Data Entry - Android app

Your HTML file (unchanged) is bundled in app/src/main/assets/index.html and runs
inside a WebView. Works fully offline; needs no permissions.

## Build the APK - Option A: GitHub (no Android Studio needed)
1. Create a free GitHub repository and upload everything in this folder
   (make sure .github/workflows/build-apk.yml is included; if the web uploader skips it,
   use Add file -> Create new file and paste it in with that exact path).
2. Open the Actions tab -> "Build APK" -> wait about 5 minutes.
3. Open the finished run -> download LegalHeirApp-APK (zip) -> unzip -> app-debug.apk.
4. Copy the APK to the phone, open it, allow "Install unknown apps" when asked.

## Option B: Android Studio
File -> Open -> select this folder -> wait for Gradle sync ->
Build -> Build Bundle(s) / APK(s) -> Build APK(s).

## Notes
- Records, users and settings are stored on the phone (localStorage). Uninstalling the app
  deletes them, so use "Download JSON Backup" regularly.
- Download buttons (JSON/CSV/backups) open Android's "Save as" screen.
- Print / Download PDF opens Android's print screen; choose "Save as PDF".
- To change the HTML later, replace app/src/main/assets/index.html and rebuild.
- For the Play Store you would need a signed release build; a debug APK is fine for direct install.
